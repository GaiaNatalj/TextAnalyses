﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace User
{
    // ResponseMessage class declaration
    public class ResponseMessage
    {
        public string Message { get; set; }
    }

    public class ResponseMessage2
    {
        public string Message { get; set; }
        public string Words { get; set; }
    }

    public class ResponseMessage3
    {
        public string Img1 { get; set; }
        public string Img2 { get; set; }
    }
}