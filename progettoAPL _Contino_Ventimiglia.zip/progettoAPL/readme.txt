Installazioni 
1) Dipendenze python
Mettersi dentro la cartella "ServerPython" e aprire il terminale e lanciare il comando:
pip install -r requirements.txt

AVVIO
1) Connettere il server mongoDB

2) Avviare il server GO
Mettersi dentro la cartella "ServerGo" e aprire il terminale e lanciare il comando:
go run main.go


3) Avviare il server Python
Mettersi dentro la cartella "ServerPython" e aprire il terminale e lanciare il comando:
py main.py

4) Avviare il client C#
